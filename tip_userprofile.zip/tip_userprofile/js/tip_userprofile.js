(function($){
  Drupal.behaviors.qtip = {
    attach: function (context, settings) {
      $(document).ready(function () {
        var instances = $.parseJSON(settings.instances);
        var debug = $.parseJSON(settings.qtipDebug);
        var instance_id = settings.tip_userprofile.qtip_instance_id;
        $('.mentions, .qtip-link').each(function() {
          if (settings) {
            $(this).qtip(instances[instance_id]);
            $(this).qtip('option', 'content.text', function(event, api) {
              var path = this.attr('href') + '/ajaxbuzz';
              $.ajax({
                url: path // Use data-url attribute for the URL
              }).then(function(content) {
                // Set the tooltip content upon successful retrieval
                api.set('content.text', content);
              }, function(xhr, status, error) {
                // Upon failure... set the tooltip content to the status and error value
                api.set('content.text', status + ': ' + error);
              });
              return 'Loading...'; // Set some initial text
            });
          }else{
            $(this).qtip({
              content: {
                text: function(event, api) {
                  var path = this.attr('href') + '/ajaxbuzz';
                  $.ajax({
                    url: path // Use data-url attribute for the URL
                  }).then(function(content) {
                    // Set the tooltip content upon successful retrieval
                    api.set('content.text', content);
                  }, function(xhr, status, error) {
                    // Upon failure... set the tooltip content to the status and error value
                    api.set('content.text', status + ': ' + error);
                  });
                  return 'Loading...'; // Set some initial text
                }
              }
            });
          }
        });
      });
    }
  };
})(jQuery);