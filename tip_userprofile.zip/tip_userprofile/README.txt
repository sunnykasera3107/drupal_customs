The Tip Userprofile is a Buzz tooptip module based on mentions and qtip.

Recommended Modules
--------------------------------------------------------------------------------

* Mentions 		- https://drupal.org/project/mentions
* qtip         - https://drupal.org/project/qtip


Usage / Configuration
--------------------------------------------------------------------------------

Once installed, the Tip Userprofile module. Then you just need to go to settings
of tip userprofile module on admin/config/content/mentions/views_setting and put
views, display id, qtip instance machine name to be use for styling, user url and 
argument to be passing in views. 

Importnat: The views display should only be of "PAGE" type. And we sends a argument
of user id on "Row value from URL" = "3".