The booking module is a custom module based on webform module.
It provides us list of componenets related to booking information in a webform.
When user submit those all information and send it so it simple sends those all information to configured email address.

Steps to install it.

 --> Put the module in module directory. And enable it with required dependencies.
 --> Create a webform node. And put that node ID in the Site admin -> configuration -> booking form settings.
 --> And if you want some prefix or suffix of that form then put it in the prefix and suffix field.

 --> Go to webform component setting and click on import link copy all the data of webform-components.txt and paste it in import textarea.
 
 Also to configure a block of this webform, you just need ot follow these steps

 --> Go to webform component setting and click on "Form settings" and in Advance settings accordian checked the "Available as block".
 